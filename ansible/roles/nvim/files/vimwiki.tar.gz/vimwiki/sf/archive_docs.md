Stałe dotyczące partów
starfish/src/sfutils/archive_targets/base_archive_target.py:239

do vesrioning potrzebne subscription_id

walidacja archive target dla azure
starfish/src/sfutils/archive_targets/storage_configs.py:545
