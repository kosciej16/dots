Jenkins katalog perf, copy kopiuje, potem można odpalić.

sf-edge
/home/jenkins/perf_results_history/Starfish/perf/Starfish_1M_over_100M_partitioned/stats/test_name

