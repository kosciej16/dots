# Logi
PR - status - bad part - logs
logs are under /home/jenkins/test/<pipeline name>#<build number>

# Get credentials:
Maage Jenkins -> Script Console -> run this script:

```
import jenkins.*
import jenkins.model.* 
import hudson.*
import hudson.model.*
def jenkinsCredentials = com.cloudbees.plugins.credentials.CredentialsProvider.lookupCredentials(
        com.cloudbees.plugins.credentials.Credentials.class,
        Jenkins.instance,
        null,
        null
);
for (creds in jenkinsCredentials) {
    println(creds.id)
    if (creds.hasProperty('description')) println("   description: " + creds.description);
    if (creds.hasProperty('secret')) println("   secret: " + creds.secret);
    if (creds.hasProperty('username')) println("   username: " + creds.username);
    if (creds.hasProperty('password')) println("   password: " + creds.password);
    if (creds.hasProperty('privateKey')) println("   privateKey: " + creds.privateKey); 
}
```


