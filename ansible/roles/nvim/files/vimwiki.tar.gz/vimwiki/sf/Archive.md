
[archive_docs](archive_docs)
Delay with progress

recover vs restore

id: 10
src: sf_small:
target: sf_s3:
query: (empty)
start time: 2023-12-13 01:18:53
end time: -
options:
 allow_overlapping_job=False
 workers_per_agent=[]
 from_scratch=False
 command_verbose=False
 dedup=False
 tar=False
 generate_manifests=False
 migrate=False
 remove_empty_dirs=False
 skip_tag_pinning=False
started by: starfish_admin

status: IN_PROGRESS
phase: Removing source (jobs: no low level job)

stats:
 Uploading files (jobs: 97):
  6 found, 6 done, 0 failed, 0 timed out, 0 temp errors
 Pinning tags (jobs: no low level job):
  6 found, 6 done, 0 failed, 0 timed out, 0 temp errors
 Removing source (jobs: no low level job):
  0 found, 0 done, 0 failed, 0 timed out, 0 temp errors


Why there is --from-file for archive?

POINT_IN_TIME for restore?
starfish/src/sfarchive/api_resources/restore_jobs.py:183

co z usuwaniem w przypadku wersji?


DefaultAzureCredential failed to retrieve a token from the included credentials.
Attempted credentials:
        EnvironmentCredential: EnvironmentCredential authentication unavailable. Environment variables are not fully configured.
Visit https://aka.ms/azsdk/python/identity/environmentcredential/troubleshoot to troubleshoot this issue.
        ManagedIdentityCredential: ManagedIdentityCredential authentication unavailable, no response from the IMDS endpoint.
        SharedTokenCacheCredential: SharedTokenCacheCredential authentication unavailable. No accounts were found in the cache.
        AzureCliCredential: ERROR: AADSTS9002313: Invalid request. Request is malformed or invalid. Trace ID: e20bc8ed-90d3-4248-aa2c-3f84049ac700 Correlation ID: 55761cc9-43bb-43c6-ac92-ee300e7ab5d8 Timestamp: 2023-12-22 13:32:19Z
Interactive authentication is needed. Please run:
az login --scope https://management.azure.com/.default

        AzurePowerShellCredential: PowerShell is not installed
        AzureDeveloperCliCredential: Azure Developer CLI could not be found. Please visit https://aka.ms/azure-dev for installation instructions and then,once installed, authenticate to your Azure account using 'azd auth login'.
To mitigate this issue, please refer to the troubleshooting guidelines here at https://aka.ms/azsdk/python/identity/defaultazurecredential/troubleshoot.
Traceback (most recent call last):
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/home.py", line 28, in <module>
    blob_service_list = client.blob_services.get_service_properties("kosciej_resource", acc)
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/tracing/decorator.py", line 78, in wrapper_use_tracer
    return func(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/mgmt/storage/v2023_01_01/operations/_blob_services_operations.py", line 490, in get_service_properties
    pipeline_response: PipelineResponse = self._client._pipeline.run(  # pylint: disable=protected-access
                                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/_base.py", line 230, in run
    return first_node.send(pipeline_request)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/_base.py", line 86, in send
    response = self.next.send(request)
               ^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/_base.py", line 86, in send
    response = self.next.send(request)
               ^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/_base.py", line 86, in send
    response = self.next.send(request)
               ^^^^^^^^^^^^^^^^^^^^^^^
  [Previous line repeated 2 more times]
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/mgmt/core/policies/_base.py", line 46, in send
    response = self.next.send(request)
               ^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/policies/_redirect.py", line 197, in send
    response = self.next.send(request)
               ^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/policies/_retry.py", line 531, in send
    response = self.next.send(request)
               ^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/policies/_authentication.py", line 124, in send
    self.on_request(request)
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/core/pipeline/policies/_authentication.py", line 99, in on_request
    self._token = self._credential.get_token(*self._scopes)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/identity/_credentials/default.py", line 225, in get_token
    token = super().get_token(*scopes, claims=claims, tenant_id=tenant_id, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/kosciej/repos/other/playground/python/3rd/azure_/.direnv/python-3.11/lib/python3.11/site-packages/azure/identity/_credentials/chained.py", line 124, in get_token
    raise ClientAuthenticationError(message=message)
azure.core.exceptions.ClientAuthenticationError: DefaultAzureCredential failed to retrieve a token from the included credentials.
Attempted credentials:
        EnvironmentCredential: EnvironmentCredential authentication unavailable. Environment variables are not fully configured.
Visit https://aka.ms/azsdk/python/identity/environmentcredential/troubleshoot to troubleshoot this issue.
        ManagedIdentityCredential: ManagedIdentityCredential authentication unavailable, no response from the IMDS endpoint.
        SharedTokenCacheCredential: SharedTokenCacheCredential authentication unavailable. No accounts were found in the cache.
        AzureCliCredential: ERROR: AADSTS9002313: Invalid request. Request is malformed or invalid. Trace ID: e20bc8ed-90d3-4248-aa2c-3f84049ac700 Correlation ID: 55761cc9-43bb-43c6-ac92-ee300e7ab5d8 Timestamp: 2023-12-22 13:32:19Z
Interactive authentication is needed. Please run:
az login --scope https://management.azure.com/.default

        AzurePowerShellCredential: PowerShell is not installed
        AzureDeveloperCliCredential: Azure Developer CLI could not be found. Please visit https://aka.ms/azure-dev for installation instructions and then,once installed, authenticate to your Azure account using 'azd auth login'.
To mitigate this issue, please refer to the troubleshooting guidelines here at https://aka.ms/azsdk/python/identity/defaultazurecredential/troubleshoot.


