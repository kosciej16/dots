sf-edge - postgres, logi w /var/lib/postgresql/pg_log
