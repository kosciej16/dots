starfish/src/sfutils/auth/identity.py

client/src/sfclient/actions/auth_tokens.py
path = .config/starftsh, fallback_path = .cache/starfish
