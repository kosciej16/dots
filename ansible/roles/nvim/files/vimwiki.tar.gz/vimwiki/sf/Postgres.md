Logi:
(np na sf-edge)
/mnt/vg_db-lv_db/postgresql/13/main/pg_log


pgagent -l 2 -f "dbname=postgres user=starfish"
