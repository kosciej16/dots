# Monitor
    sf volume set-user-params test2 fake_event_monitor.run_method=out_of_sync
    sf volume set-monitor-type test2 fake_event_monitor

    #  /tmp/starfish-kosciej/etc/99-local.ini
    [monitor:fake_event_monitor]
    init=/bin/true
    event_monitor=/home/kosciej/itsg/fake.sh
    pause=/bin/true
    cleanup=/bin/true
