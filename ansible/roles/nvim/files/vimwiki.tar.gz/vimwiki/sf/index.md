Migracje: 
starfish/src/sfutils/pg_api/migrate.py start_background_migrations

[Redash](Redash)

[Scans](Scans)

[Postgres](Postgres)

[Queries](Queries)

[Auth](Auth)

[Jenkins](Jenkins)

[Perfy](Perfy)

[Maszyny](Maszyny)

[tests](tests)

[smokeman](smokeman)

INFLUXDB_API_TOKEN=ouichweociuhwoeibwoefbowfn4rim43ormfnvlrevre

zendesk:
engineering@starfishstorage.com
979dbb971140f57ac10b3f1f77ba6b70

[Archive](Archive)

%% FROM sf.dir_current AS dir LEFT OUTER JOIN sf.job_result_current AS job_result_000001 ON dir.id = job_result_000001.fs_entry_id AND dir.volume_id = job_result_000001.volume_id AND job_result_000001.name_id IN (1) AND (job_result_000001.ctime = dir.ctime OR job_result_000001.ctime IS NULL) AND (job_result_000001.mtime = dir.mtime OR job_result_000001.mtime IS NULL) AND job_result_000001.name_id = 1 JOIN (SELECT DISTINCT any_path_filter_000003.parent_path AS parent_path, any_path_filter_000003.name AS name
%% FROM _any_path_filter_20240401_000011_000002 AS any_path_filter_000003) AS any_path_filter_dir ON dir.path = concat(coalesce(nullif(concat(any_path_filter_dir.parent_path, '/'), '/'), ''), any_path_filter_dir.name)
%% WHERE dir.volume_id = 1011 AND job_result_000001.fs_entry_id IS NULL AND dir.volume_id = 1011 AND dir.volume_id IN (1011))
%% UNION ALL
%% (SELECT file.id AS id, file.type AS entry_type, file.inode AS ino, file.name AS fn, parent.path AS parent_path, file.size AS size, file.mtime AS mt, file.ctime AS ct
%% FROM sf.file_current AS file JOIN sf.dir_current AS parent ON parent.id = file.parent_id AND parent.volume_id = file.volume_id LEFT OUTER JOIN sf.job_result_current AS job_result_000001 ON file.id = job_result_000001.fs_entry_id AND file.volume_id = job_result_000001.volume_id AND job_result_000001.name_id IN (1) AND (job_result_000001.ctime = file.ctime OR job_result_000001.ctime IS NULL) AND (job_result_000001.mtime = file.mtime OR job_result_000001.mtime IS NULL) AND job_result_000001.name_id = 1 JOIN (SELECT DISTINCT any_path_filter_000003.parent_path AS parent_path, any_path_filter_000003.name AS name
%% FROM _any_path_filter_20240401_000011_000002 AS any_path_filter_000003) AS any_path_filter ON parent.path = any_path_filter.parent_path AND file.name = any_path_filter.name                                                                  WHERE file.volume_id = 1011 AND job_result_000001.fs_entry_id IS NULL AND file.volume_id = 1011 AND file.volume_id IN (1011) AND parent.volume_id IN (1011))                                                                                  Append  (cost=2030095.96..5341696.52 rows=79251 width=132) (actual rows=0 loops=1)                                                                                                                                                              ->  Merge Join  (cost=2030095.96..2034573.30 rows=78895 width=84) (actual rows=0 loops=1)
%%         Merge Cond: (dir.path = (concat(COALESCE(NULLIF(concat(any_path_filter_dir.parent_path, '/'), '/'::text), ''::text), any_path_filter_dir.name)))                                                                                              ->  Sort  (cost=1687917.24..1687981.46 rows=128448 width=159) (actual rows=68361 loops=1)
%%               Sort Key: dir.path                                                                                                                                                                                                                            Sort Method: quicksort  Memory: 16135kB
%%               ->  Gather  (cost=1000.11..1685737.37 rows=128448 width=159) (actual rows=74251 loops=1)                                                                                                                                                            Workers Planned: 6                                                                                                                                                                                                                            Workers Launched: 6
%%                     ->  Nested Loop Anti Join  (cost=0.11..1671892.57 rows=21408 width=159) (actual rows=10607 loops=7)
%%                           ->  Parallel Seq Scan on dir_current_part_11 dir  (cost=0.00..1070541.74 rows=386927 width=167) (actual rows=331652 loops=7)                                                                                                                        Filter: (volume_id = 1011)
%%                                 Rows Removed by Filter: 1                                                                                                                                                                                                               ->  Index Scan using job_result_current_part_11_volume_id_fs_entry_id_name_id_key on job_result_current_part_11 job_result_000001  (cost=0.11..1.54 rows=1 width=32) (actual rows=1 loops=2321561)
%%                                 Index Cond: ((volume_id = dir.volume_id) AND (volume_id = 1011) AND (fs_entry_id = dir.id) AND (name_id = 1))
%%                                 Filter: ((((ctime)::timestamp with time zone = (dir.ctime)::timestamp with time zone) OR (ctime IS NULL)) AND (((mtime)::timestamp with time zone = (dir.mtime)::timestamp with time zone) OR (mtime IS NULL)))
%%                                 Rows Removed by Filter: 0
%%         ->  Sort  (cost=342178.73..342804.84 rows=1252234 width=167) (actual rows=8158312 loops=1)
%%               Sort Key: (concat(COALESCE(NULLIF(concat(any_path_filter_dir.parent_path, '/'), '/'::text), ''::text), any_path_filter_dir.name))                                                                                                             Sort Method: external sort  Disk: 2829072kB
%%               ->  Subquery Scan on any_path_filter_dir  (cost=291768.70..316813.38 rows=1252234 width=167) (actual rows=8158312 loops=1)                                                                                                                          ->  HashAggregate  (cost=291768.70..304291.04 rows=1252234 width=167) (actual rows=8158312 loops=1)                                                                                                                                                 Group Key: any_path_filter_000003.parent_path, any_path_filter_000003.name
%%                           Batches: 5  Memory Usage: 778289kB  Disk Usage: 994304kB                                                                                                                                                                                      ->  Seq Scan on _any_path_filter_20240401_000011_000002 any_path_filter_000003  (cost=0.00..283616.73 rows=8151973 width=167) (actual rows=8158312 loops=1)                                                           ->  Subquery Scan on "*SELECT* 2"  (cost=291769.04..3305938.02 rows=356 width=171) (actual rows=0 loops=1)
%%         ->  Nested Loop Anti Join  (cost=291769.04..3305934.46 rows=356 width=171) (actual rows=0 loops=1)                                                                                                                                                  ->  Nested Loop  (cost=291768.93..3305605.33 rows=1518 width=179) (actual rows=7837252 loops=1)                                                                                                                                                     ->  HashAggregate  (cost=291768.70..304291.04 rows=1252234 width=167) (actual rows=8158312 loops=1)                                                                                                                                                 Group Key: any_path_filter_000003_1.parent_path, any_path_filter_000003_1.name
%%                           Batches: 5  Memory Usage: 778289kB  Disk Usage: 994304kB                                                                                                                                                                                      ->  Seq Scan on _any_path_filter_20240401_000011_000002 any_path_filter_000003_1  (cost=0.00..283616.73 rows=8151973 width=167) (actual rows=8158312 loops=1)                                                                           ->  Nested Loop  (cost=0.22..2.38 rows=1 width=179) (actual rows=1 loops=8158312)                                                                                                                                                                   ->  Index Scan using dir_current_part_11_volume_id_path_idx on dir_current_part_11 parent  (cost=0.11..0.81 rows=1 width=123) (actual rows=1 loops=8158312)                                                                                         Index Cond: ((volume_id = 1011) AND (path = any_path_filter_000003_1.parent_path))
%%                           ->  Index Scan using file_current_part_11_volume_id_parent_id_name_key on file_current_part_11 file  (cost=0.11..1.56 rows=1 width=80) (actual rows=1 loops=8158312)                                                                                Index Cond: ((volume_id = 1011) AND (parent_id = parent.id) AND (name = any_path_filter_000003_1.name))                                                                                                                     ->  Index Scan using job_result_current_part_11_volume_id_fs_entry_id_name_id_key on job_result_current_part_11 job_result_000001_1  (cost=0.11..0.21 rows=1 width=32) (actual rows=1 loops=7837252)
%%                     Index Cond: ((volume_id = file.volume_id) AND (volume_id = 1011) AND (fs_entry_id = file.id) AND (name_id = 1))
%%                     Filter: ((((ctime)::timestamp with time zone = (file.ctime)::timestamp with time zone) OR (ctime IS NULL)) AND (((mtime)::timestamp with time zone = (file.mtime)::timestamp with time zone) OR (mtime IS NULL)))

