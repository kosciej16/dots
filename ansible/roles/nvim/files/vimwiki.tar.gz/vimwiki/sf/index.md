Migracje: 
starfish/src/sfutils/pg_api/migrate.py start_background_migrations

[Redash](Redash)

[Scans](Scans)

[Postgres](Postgres)

[Queries](Queries)

[Auth](Auth)

[Jenkins](Jenkins)

[Perfy](Perfy)

[Maszyny](Maszyny)

[tests](tests)

[smokeman](smokeman)

INFLUXDB_API_TOKEN=ouichweociuhwoeibwoefbowfn4rim43ormfnvlrevre

zendesk:
engineering@starfishstorage.com
979dbb971140f57ac10b3f1f77ba6b70

[Archive](Archive)

[Unused](Unused)

TASK:
Tabelka na razie tylko ID i URL
endpoint w volume /agents
Autodiscovery zbadać (agenci sami informują o wolumenach)
