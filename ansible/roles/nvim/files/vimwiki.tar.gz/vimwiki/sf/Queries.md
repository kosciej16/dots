SELECT id, volume_id
FROM (
select 
    id, 
    volume_id, 
    rank() over (partition by volume_id order by id desc) as r
from sf_scans.scan s 
) t 
WHERE r<=2;

find_entries_in_session
starfish/src/sfutils/pg_api/fs_entries.py:474
