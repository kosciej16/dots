Script called with arguments: /home/kosciej/repos/itsg/local/starfish/scripts/installation/_redis.sh  --log-file _redash.log --listen-address 127.0.0.1 --port 6382 --password IIpewOP0oFqcDn9Y5FYhwA8e --redis-dir /tmp/starfish-kosciej/redash-systemd/10.1.0/redis --username redash

REDASH_DEFAULT_EMAIL = 'starfish@starfishstorage.com'
# nosec B105 because this password is not used anymore, left only for backwards compat, new installs have random pass.
REDASH_DEFAULT_PASSWORD = "Starfish123"  # nosec B105

