    def test_me(self):
        self._start_with_standard_system_config(initial_scan=False, config_overrides={"client.http_timeout": 3})
        fs_description = Dir("root", File("file1", content="foo"), File("file2", content="foo"))
        fs_path = self._materialize(fs_description)
        self._create_volume("vol", fs_description, store_posix_acl=True)
        self._run_scan(Scan.Type.SYNC, "vol")

        with self.pg_db_api.transaction_ctx() as session:
            session.execute(f"LOCK TABLE {DirCurrent.full_table_name_with_suffix(1)} IN ACCESS SHARE MODE")
            self._run_sf_client("volume", "remove", "vol", "--force")
            session.execute(f"LOCK TABLE {DbVolume.full_table_name()} IN EXCLUSIVE MODE")
            self._run_sf_client("volume", "add", "vol", fs_path, expected_returncode=ExitCodes.TIMEOUT)

    def test_remove_volume(self):

