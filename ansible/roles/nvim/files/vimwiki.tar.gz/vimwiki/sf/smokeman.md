na maszynach Jenkinsowych konfigurujemy fsync=off, żeby testy działały jak najszybciej
efektem ubocznym jest to, że twardy reboot w 99% kończy się zepsutą bazą danych

joby reboot host, reset postgresql w maintainance
