config:
starfish/src/sfutils/directories.py

tests/sftests/integration/installer.py

Limit path
tests/sfpytest/plugins/limit_tests.py:22

services
tests/sftests/integration/utils.py:129

db_helper:
get_alembic_dir_path tests/sftests/fs_entries_helper.py:867
tests/sftests/unittest_fixtures/common.py

unittests:

ServiceTestCase - tests for services. ALlows for sending requests
SfUnitWithDbTestCase - adding db
SfUnitTestCase - adding some cleanup, method for mocks
SfTestWithLogging - setup logger
SFTestCase - adding some log level
TestCase
