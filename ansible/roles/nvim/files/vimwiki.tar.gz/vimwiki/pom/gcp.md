Your project default Compute Engine zone has been set to [us-central1-a].
You can change it by running [gcloud config set compute/zone NAME].

Your project default Compute Engine region has been set to [us-central1].
You can change it by running [gcloud config set compute/region NAME].

Your Google Cloud SDK is configured and ready to use!

* Commands that require authentication will use dowolkry@cs.corpnet.pl by default
* Commands will reference project `opl-training-platform-loc` by default
* Compute Engine commands will use region `us-central1` by default
* Compute Engine commands will use zone `us-central1-a` by default

Run `gcloud help config` to learn how to change individual settings

This gcloud configuration is called [pom-loc]. You can create additional configurations if you work with multiple accounts and/or projects.
Run `gcloud topic configurations` to learn more.

Some things to try next:

* Run `gcloud --help` to see the Cloud Platform services you can interact with. And run `gcloud help COMMAND` to get help on any gcloud command.
* Run `gcloud topic --help` to learn about advanced features of the SDK like arg files and output formatting
* Run `gcloud cheat-sheet` to see a roster of go-to `gcloud` commands.


# Instancja do testowania na GPC
Instancja `training-instance` jest utworzona w projekcie [opl-training-platform-loc](https://console.cloud.google.com/compute/instances?project=opl-training-platform-loc).

## Dostęp
Maszyna jest wyłączona, aby nie generować kosztów. Należy najpierw ją uruchomić klikając `start / resume`. Następnie kopiujemy jej `External IP`
### ssh
Należy najpierw dodać swój publiczny klucz, którego chcemy użyć. By to zrobić wchodzimy w edycję maszyny i zjeżdżamy do sekcji `SSH Keys`. Następnie można już połączyć się przez putty korzystając z odpowiedniego klucza i IP. Jeśli mamy skonfigurowanego `gcloud`, można też użyć
`gcloud compute ssh training-instance`
### RDP
Na maszynie jest skonfigurowane środowisko graficzne i RDP. User: `rdp_user`, hasło: `pass`

## Konfiguracja i uruchomienie
Na maszynie znajdziemy potrzebne do modeli biblioteki. Wszystko znajduje się w virtualenvie (`source /home/kosciej/env/ml/bin/activate).


# Buckets

In the Permissions section, click the person_add Grant access button.
The Grant access dialog appears.
In the New principals field, enter allUsers.

In the Select a role drop down, enter Storage Object Viewer in the filter box and select the Storage Object Viewer from the filtered results.
