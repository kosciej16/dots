acquisitor:

Type:      NFS (an NFS mount that lasts the lifetime of a pod)                                                                                                                                                                                                           │
Server:    nc11-vnasprod-nfs03-2750-1.storage.corpnet.pl                                                                                                                                                                                                                 │
Path:      /mml_dat01/msacquisitor                                                                                                                                                                                                                                       │
ReadOnly:  false                                                                                                                                                                                                                                                         │
