mongosh --host localhost -u msknedle -p p3GuWYUxhd4s6Z_K
mongosh --host localhost -u feedback -p JkmnFFghd3458621G

%% mongosh 'mongodb://feedback:JkmnFFghd3458621G@pbccml01.corpnet.pl:27017,pbccml02.corpnet.pl:27017,pbccml03.corpnet.pl:27017/?authSource=admin&replicaSet=RS1&readPreference=primary&ssl=true&tlsCAFile=%2Fopt%2Fcerts%2ForangeCAchain.pem&tlsCertificateFile=%2Fopt%2Fcerts%2Fpagpu01.corpnet.pl.crt&tlsCertificateKeyFile=%2Fopt%2Fcerts%2Fpagpu01.corpnet.pl.key'
mongosh 'mongodb://feedback:JkmnFFghd3458621G@pbccml01.corpnet.pl:27017,pbccml02.corpnet.pl:27017,pbccml03.corpnet.pl:27017/?authSource=admin&replicaSet=RS1&readPreference=primary&ssl=true&tlsCAFile=%2Fopt%2Fcerts%2ForangeCAchain.pem&tlsCertificateFile=%2Fssl%2Fcm.crt&tlsCertificateKeyFile=%2Fssl%%2Fca.crt'
mongosh 'mongodb://msknedle:p3GuWYUxhd4s6Z_K@pbccml01.corpnet.pl:27017,pbccml02.corpnet.pl:27017,pbccml03.corpnet.pl:27017/?authSource=admin&replicaSet=RS1&readPreference=primary&ssl=true&tlsCAFile=%2Fopt%2Fcerts%2ForangeCAchain.pem&tlsCertificateFile=%2Fopt%2Fcerts%2Fpagpu01.corpnet.pl.crt&tlsCertificateKeyFile=%2Fopt%2Fcerts%2Fpagpu01.corpnet.pl.key'

[gcp](gcp)
[maszyny](maszyny)


CUDA 11.8

docelowo:

mamay instancje skonfigurowaną do treningu
dwie karty L4
mlflow, nni + to co potrzebne do treningu
sprawdzić drivery (wersje ) z punktu widzenia Torch

jak działą msknedle i mskendle sat
jak prznosić funkcjonalności
jak łączyć infomracje

absl-py==1.4.0
aiofiles==22.1.0
aiohttp==3.8.4
aiosignal==1.3.1
aiosqlite==0.18.0
alembic==1.10.3
anyio==3.6.2
argon2-cffi==21.3.0
argon2-cffi-bindings==21.2.0
arrow==1.2.3
astor==0.8.1
asttokens==2.2.1
astunparse==1.6.3
async-timeout==4.0.2
attrs==22.2.0
Babel==2.12.1
backcall==0.2.0
beautifulsoup4==4.12.2
bleach==6.0.0
blessed==1.20.0
blis==0.7.9
bokeh==2.4.3
cachetools==5.3.0
catalogue==2.0.8
catboost==1.1.1
certifi==2022.12.7
cffi==1.15.1
charset-normalizer==3.1.0
click==8.1.3
cloudpickle==2.2.1
cmaes==0.9.1
cmake==3.25.0
colorama==0.4.6
colorlog==6.7.0
comm==0.1.3
confection==0.0.4
contextlib2==21.6.0
contourpy==1.0.7
croniter==1.3.10
cycler==0.11.0
cymem==2.0.7
dask==2023.3.2
databricks-cli==0.17.6
datasets==2.11.0
dateutils==0.6.12
debugpy==1.6.7
decorator==5.1.1
deepdiff==6.3.0
defusedxml==0.7.1
dill==0.3.6
distributed==2023.3.2
dnspython==2.3.0
docker==6.0.1
email-validator==1.3.1
entrypoints==0.4
et-xmlfile==1.1.0
exceptiongroup==1.1.2
executing==1.2.0
faiss-cpu==1.7.4
faiss-gpu==1.7.2
fastapi==0.88.0
fastjsonschema==2.16.3
filelock==3.9.0
Flask==2.2.3
flatbuffers==23.3.3
fonttools==4.39.3
fqdn==1.5.1
frozenlist==1.3.3
fsspec==2023.4.0
funcy==2.0
future==0.18.3
gast==0.4.0
gensim==4.3.1
gitdb==4.0.10
GitPython==3.1.31
google-auth==2.17.2
google-auth-oauthlib==1.0.0
google-pasta==0.2.0
graphviz==0.20.1
greenlet==2.0.2
grpcio==1.53.0
gunicorn==20.1.0
h11==0.14.0
h5py==3.8.0
HeapDict==1.0.1
httpcore==0.16.3
httptools==0.5.0
httpx==0.23.3
huggingface-hub==0.13.4
hyperopt==0.2.7
idna==3.4
imageio==2.27.0
importlib-metadata==6.2.0
importlib-resources==5.12.0
iniconfig==2.0.0
inquirer==3.1.3
install==1.3.5
ipykernel==6.22.0
ipython==8.12.0
ipython-genutils==0.2.0
ipywidgets==8.0.6
isoduration==20.11.0
itsdangerous==2.1.2
jax==0.4.8
jedi==0.18.2
Jinja2==3.1.2
joblib==1.2.0
json-tricks==3.16.1
json5==0.9.11
jsonpointer==2.3
jsonschema==4.17.3
jupyter-events==0.6.3
jupyter-ydoc==0.2.3
jupyter_client==8.1.0
jupyter_core==5.3.0
jupyter_server==2.5.0
jupyter_server_fileid==0.8.0
jupyter_server_terminals==0.4.4
jupyter_server_ydoc==0.8.0
jupyterlab==3.6.3
jupyterlab-pygments==0.2.2
jupyterlab-widgets==3.0.7
jupyterlab_server==2.22.0
keras==2.12.0
kiwisolver==1.4.4
langcodes==3.3.0
lazy_loader==0.2
libclang==16.0.0
lightgbm==3.3.5
lightning==2.0.1
lightning-cloud==0.5.32
lightning-utilities==0.8.0
lit==15.0.7
llvmlite==0.39.1
locket==1.0.0
lz4==4.3.2
Mako==1.2.4
Markdown==3.4.3
markdown-it-py==2.2.0
MarkupSafe==2.1.2
matplotlib==3.7.1
matplotlib-inline==0.1.6
mdurl==0.1.2
mistune==2.0.5
ml-dtypes==0.0.4
mlflow==2.2.2
mlflow-export-import==1.2.0
mpmath==1.2.1
msgpack==1.0.5
multidict==6.0.4
multimodal-transformers==0.2a0
multiprocess==0.70.14
murmurhash==1.0.9
nbclassic==0.5.5
nbclient==0.7.3
nbconvert==7.3.0
nbformat==5.8.0
nest-asyncio==1.5.6
networkx==2.6.3
nltk==3.8.1
nni==2.10
notebook==6.5.4
notebook_shim==0.2.2
numba==0.56.4
numexpr==2.8.4
numpy==1.23.5
oauthlib==3.2.2
opencv-python==4.7.0.72
openpyxl==3.1.2
opt-einsum==3.3.0
optuna==3.1.1
ordered-set==4.1.0
orjson==3.8.9
packaging==23.0
pandas==2.0.0
pandocfilters==1.5.0
parso==0.8.3
partd==1.3.0
pathy==0.10.1
pexpect==4.8.0
pickleshare==0.7.5
Pillow==9.3.0
pkgutil_resolve_name==1.3.10
platformdirs==3.2.0
plotly==5.14.1
pluggy==1.2.0
preshed==3.0.8
prettytable==3.6.0
prometheus-client==0.16.0
prompt-toolkit==3.0.38
protobuf==4.22.1
psutil==5.9.4
ptyprocess==0.7.0
pure-eval==0.2.2
py==1.11.0
py4j==0.10.9.5
pyarrow==11.0.0
pyasn1==0.4.8
pyasn1-modules==0.2.8
pycparser==2.21
pydantic==1.10.7
pydot==1.4.2
Pygments==2.14.0
PyJWT==2.6.0
pyLDAvis==3.4.0
pymongo==4.3.3
pynvml==11.5.0
pyparsing==3.0.9
pyrsistent==0.19.3
pyspark==3.3.2
pytest==7.2.2
pytest-html==3.2.0
pytest-metadata==3.0.0
python-dateutil==2.8.2
python-dotenv==1.0.0
python-editor==1.0.4
python-json-logger==2.0.7
python-multipart==0.0.6
PythonWebHDFS==0.2.3
pytorch-lightning==2.0.2
pytz==2022.7.1
PyWavelets==1.4.1
PyYAML==6.0
pyzmq==25.0.2
querystring-parser==1.2.4
readchar==4.0.5
regex==2023.3.23
requests==2.28.2
requests-oauthlib==1.3.1
responses==0.18.0
rfc3339-validator==0.1.4
rfc3986==1.5.0
rfc3986-validator==0.1.1
rich==13.3.3
rsa==4.9
sacremoses==0.0.53
schema==0.7.5
scikit-image==0.20.0
scikit-learn==1.2.2
scipy==1.9.1
seaborn==0.12.2
Send2Trash==1.8.0
shap==0.41.0
shortuuid==1.0.11
simplejson==3.19.1
six==1.16.0
slicer==0.0.7
smart-open==6.3.0
smmap==5.0.0
sniffio==1.3.0
sortedcontainers==2.4.0
soupsieve==2.4
spacy==3.5.1
spacy-legacy==3.0.12
spacy-loggers==1.0.4
SQLAlchemy==2.0.9
sqlparse==0.4.3
srsly==2.4.6
stack-data==0.6.2
starlette==0.22.0
starsessions==1.3.0
sympy==1.11.1
tabulate==0.9.0
tblib==1.7.0
tenacity==8.2.2
tensorboard==2.12.3
tensorboard-data-server==0.7.0
tensorboard-plugin-wit==1.8.1
tensorflow==2.12.0
tensorflow-estimator==2.12.0
tensorflow-io-gcs-filesystem==0.32.0
termcolor==2.2.0
terminado==0.17.1
thinc==8.1.9
threadpoolctl==3.1.0
tifffile==2023.3.21
tinycss2==1.2.1
tokenizers==0.13.3
tomli==2.0.1
toolz==0.12.0
torch==2.0.0+cu118
torchaudio==2.0.1+cu118
torchensemble==0.1.9
torchinfo==1.7.2
torchmetrics==0.11.4
torchvision==0.15.1+cu118
tornado==6.2
tqdm==4.64.1
traitlets==5.9.0
transformers==4.27.4
triton==2.0.0
typeguard==2.13.3
typer==0.7.0
typing_extensions==4.5.0
tzdata==2023.3
ujson==5.7.0
uri-template==1.2.0
urllib3==1.26.15
uvicorn==0.21.1
uvloop==0.17.0
wasabi==1.1.1
watchfiles==0.19.0
wcwidth==0.2.6
webcolors==1.13
webencodings==0.5.1
websocket-client==1.5.1
websockets==11.0.1
Werkzeug==2.2.3
widgetsnbextension==4.0.7
wrapt==1.14.1
xgboost==1.7.5
xxhash==3.2.0
y-py==0.5.9
yarl==1.8.2
ypy-websocket==0.8.2
zict==2.2.0
zipp==3.15.0


orlica:

absl-py==2.1.0
accelerate==0.30.1
aiohttp==3.9.5
aiosignal==1.3.1
alembic==1.13.1
aniso8601==9.0.1
annotated-types==0.6.0
appdirs==1.4.4
astor==0.8.1
asttokens==2.4.1
astunparse==1.6.3
async-timeout==4.0.3
attrs==23.2.0
bertopic==0.16.1
blinker==1.8.2
blis==0.7.11
cachetools==5.3.3
catalogue==2.0.10
catboost==1.2.5
certifi==2024.2.2
charset-normalizer==3.3.2
click==8.1.7
cloudpathlib==0.16.0
cloudpickle==3.0.0
colorama==0.4.6
comm==0.2.2
confection==0.1.4
contourpy==1.2.1
cupy-cuda11x==12.3.0
curated-tokenizers==0.0.9
curated-transformers==0.1.1
cycler==0.12.1
cymem==2.0.8
Cython==0.29.37
datasets==2.19.0
debugpy==1.8.1
decorator==5.1.1
deepspeed==0.12.6
dill==0.3.8
dnspython==2.6.1
docker==7.0.0
docker-pycreds==0.4.0
en-core-web-trf==3.7.3
entrypoints==0.4
et-xmlfile==1.1.0
exceptiongroup==1.2.1
executing==2.0.1
fastrlock==0.8.2
filelock==3.10.0
Flask==3.0.3
flatbuffers==24.3.25
fonttools==4.51.0
frozenlist==1.4.1
fsspec==2024.2.0
funcy==2.0
future==1.0.0
gast==0.5.4
gensim==4.3.2
gitdb==4.0.11
GitPython==3.1.43
google-auth==2.29.0
google-auth-oauthlib==1.0.0
google-pasta==0.2.0
graphene==3.3
graphql-core==3.2.3
graphql-relay==3.2.0
graphviz==0.20.3
greenlet==3.0.3
grpcio==1.62.2
gunicorn==21.2.0
h5py==3.11.0
hdbscan==0.8.33
hjson==3.1.0
huggingface-hub==0.22.2
hyperopt==0.1.2
idna==3.7
importlib_metadata==7.1.0
ipykernel==6.29.4
ipython==8.23.0
ipywidgets==8.1.2
itsdangerous==2.2.0
jedi==0.19.1
Jinja2==3.1.3
joblib==1.4.2
json-tricks==3.17.3
jupyter_client==8.6.1
jupyter_core==5.7.2
jupyterlab_widgets==3.0.10
keras==2.14.0
kiwisolver==1.4.5
langcodes==3.4.0
language_data==1.2.0
libclang==18.1.1
lightning==2.2.3
lightning-utilities==0.11.2
llvmlite==0.42.0
Mako==1.3.3
marisa-trie==1.1.0
Markdown==3.6
markdown-it-py==3.0.0
MarkupSafe==2.1.5
matplotlib==3.8.4
matplotlib-inline==0.1.7
mdurl==0.1.2
ml-dtypes==0.2.0
mlflow==2.12.2
mpmath==1.3.0
multidict==6.0.5
multiprocess==0.70.16
murmurhash==1.0.10
namex==0.0.8
nest-asyncio==1.6.0
networkx==3.3
ninja==1.11.1.1
nni==2.9
numba==0.59.1
numexpr==2.10.0
numpy==1.26.4
nvidia-cublas-cu11==11.11.3.6
nvidia-cublas-cu12==12.3.4.1
nvidia-cuda-cupti-cu11==11.8.87
nvidia-cuda-cupti-cu12==12.3.101
nvidia-cuda-nvcc-cu12==12.3.107
nvidia-cuda-nvrtc-cu11==11.8.89
nvidia-cuda-nvrtc-cu12==12.3.107
nvidia-cuda-runtime-cu11==11.8.89
nvidia-cuda-runtime-cu12==12.3.101
nvidia-cudnn-cu11==8.7.0.84
nvidia-cudnn-cu12==8.9.7.29
nvidia-cufft-cu11==10.9.0.58
nvidia-cufft-cu12==11.0.12.1
nvidia-curand-cu11==10.3.0.86
nvidia-curand-cu12==10.3.4.107
nvidia-cusolver-cu11==11.4.1.48
nvidia-cusolver-cu12==11.5.4.101
nvidia-cusparse-cu11==11.7.5.86
nvidia-cusparse-cu12==12.2.0.103
nvidia-ml-py==12.550.52
nvidia-nccl-cu11==2.19.3
nvidia-nccl-cu12==2.19.3
nvidia-nvjitlink-cu12==12.3.101
nvidia-nvtx-cu11==11.8.86
oauthlib==3.2.2
onnx==1.16.0
openpyxl==3.1.2
opt-einsum==3.3.0
optree==0.11.0
packaging==24.0
pandas==2.2.2
parso==0.8.4
pexpect==4.9.0
pillow==10.2.0
pl-core-news-lg==3.7.0
pl-core-news-md==3.7.0
pl-core-news-sm==3.7.0
platformdirs==4.2.1
plotly==5.21.0
polars==0.20.22
preshed==3.0.9
prettytable==3.10.0
prompt-toolkit==3.0.43
protobuf==4.25.3
psutil==5.9.8
ptyprocess==0.7.0
pure-eval==0.2.2
py-cpuinfo==9.0.0
pyarrow==15.0.2
pyarrow-hotfix==0.6
pyasn1==0.6.0
pyasn1_modules==0.4.0
pydantic==2.7.1
pydantic_core==2.18.2
pydot==2.0.0
Pygments==2.17.2
pyLDAvis==3.4.1
pymongo==4.7.2
pynndescent==0.5.12
pynvml==11.5.0
pyparsing==3.1.2
python-dateutil==2.9.0.post0
PythonWebHDFS==0.2.3
pytorch-lightning==2.2.3
pytz==2024.1
PyYAML==6.0.1
pyzmq==26.0.2
querystring-parser==1.2.4
regex==2024.4.16
requests==2.31.0
requests-oauthlib==2.0.0
responses==0.25.0
revtok==0.0.3
rich==13.7.1
rsa==4.9
sacremoses==0.1.1
safetensors==0.4.3
schema==0.7.7
scikit-learn==1.4.2
scikit-plot==0.3.7
scipy==1.11.4
seaborn==0.13.2
sentence-transformers==2.7.0
sentencepiece==0.2.0
sentry-sdk==2.0.0
setproctitle==1.3.3
simplejson==3.19.2
six==1.16.0
smart-open==6.4.0
smmap==5.0.1
spacy==3.7.4
spacy-curated-transformers==0.2.2
spacy-legacy==3.0.12
spacy-loggers==1.0.5
SQLAlchemy==2.0.30
sqlparse==0.5.0
srsly==2.4.8
stack-data==0.6.3
sympy==1.12
tabulate==0.9.0
tenacity==8.2.3
tensorboard==2.14.1
tensorboard-data-server==0.7.2
tensorflow==2.14.0
tensorflow-addons==0.23.0
tensorflow-estimator==2.14.0
tensorflow-hub==0.16.1
tensorflow-io-gcs-filesystem==0.36.0
tensorflow-text==2.14.0
termcolor==2.4.0
tf-keras==2.15.0
thinc==8.2.3
threadpoolctl==3.5.0
tokenizers==0.19.1
torch==2.2.2+cu118
torchaudio==2.2.2+cu118
torchinfo==1.8.0
torchmetrics==1.0.3
torchtext==0.17.2
torchvision==0.17.2+cu118
tornado==6.4
tqdm==4.66.4
traitlets==5.14.3
transformers==4.40.1
triton==2.2.0
typeguard==2.13.3
typer==0.9.4
types-PyYAML==6.0.12.20240311
typing_extensions==4.11.0
tzdata==2024.1
umap-learn==0.5.6
urllib3==2.2.1
wandb==0.16.6
wasabi==1.1.2
wcwidth==0.2.13
weasel==0.3.4
websockets==12.0
Werkzeug==3.0.2
widgetsnbextension==4.0.10
wrapt==1.14.1
xgboost==2.0.3
xxhash==3.4.1
yarl==1.9.4
yellowbrick==1.5
zipp==3.18.1



# Instancja do testowania na GPC
Instancja `training-instance` jest utworzona w projekcie [opl-training-platform-loc](https://console.cloud.google.com/compute/instances?project=opl-training-platform-loc).

## Dostęp
Maszyna jest wyłączona, aby nie generować kosztów. Należy najpierw ją uruchomić klikając `start / resume`. Następnie kopiujemy jej `External IP`
### ssh
Należy najpierw dodać swój publiczny klucz, którego chcemy użyć. By to zrobić wchodzimy w edycję maszyny i zjeżdżamy do sekcji `SSH Keys`. Następnie można już połączyć się przez putty korzystając z odpowiedniego klucza i IP. Jeśli mamy skonfigurowanego `gcloud`, można też użyć
`gcloud compute ssh training-instance`
### RDP
Na maszynie jest skonfigurowane środowisko graficzne i RDP. User: `rdp_user`, hasło: `pass`

## Konfiguracja i uruchomienie
Na maszynie znajdziemy potrzebne do modeli biblioteki. Wszystko znajduje się w virtualenvie (`source /home/kosciej/env/ml/bin/activate).



We need a way for running our trainings on GCP. To do that we need to create a machine where we could run our application with business data. The machine should be within `opl-training-platform-dev project`.

The machine should have 1 GPU with NVIDIA L4 card and boot disk of size 100GB and Ubuntu 22.
There is ansible playbook that should be run after the machine is created.
The machine should be stopped at the end of the creation process and run on demand (see Pipeline section)

The docker container is based on this [image](https://hub.docker.com/layers/nvidia/cuda/11.8.0-cudnn8-devel-ubuntu22.04/images/sha256-ee127a83b5269251476a3a1933972735a0a8a3269d35fda374f548212687d5db).
With extra `python3-pip` installed.

The machine should have NFS mounted where we can store many gigs of models to training.

Ideally we should have way to access the machine via ssh (22) and rdp (3389). Furthermore
access to mongo (27017) and MLflow (15001) would be very helpful.


Pipeline:
The pipeline should be parametrized with:
Optional source (path to directory in repository) and destination (path on mounted NFS).
Script name
Steps are:

Start the machine
If source and destination path is provided, copy the content of source to destination
Copy the Script name into the NFS path
Start a docker container with NFS mounted that runs such script
When the script ends, stop the machine
