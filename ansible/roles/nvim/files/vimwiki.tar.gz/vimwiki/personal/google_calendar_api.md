https://apidata.googleusercontent.com/caldav/v2/calid/events
Where calid should be replaced by the "calendar ID" of the calendar to be accessed.

https://developers.google.com/calendar/auth

[curl sh](curl.sh)
