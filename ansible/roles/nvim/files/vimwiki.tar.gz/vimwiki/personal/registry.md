maintance -> readonly
turn on when collect garbage
