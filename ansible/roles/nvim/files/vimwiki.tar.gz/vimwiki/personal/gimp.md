Transparency - różdżka (U) i w tym samym miejscu select by color (shift + O), zaznaczyć, dodać alpha layer, potem można usunąć
