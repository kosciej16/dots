colordiff -ru <(tree -v /tmp/4.15/) <(tree -v /tmp/5.0/) | less -R

ctrl-m = \n
ctrl-j = \r
lub na odwrót

to disable color fonts:
sudo apt remove fonts-noto-color-emoji
