https://rushter.com/blog/python-garbage-collector/
