systemctl list-unit-files --state=static

systemctl list-units --type help
Available unit types:
service
socket
target
device
mount
automount
swap
timer
path
slice
scope


systemd --test --system --unit=graphical.target
systemctl isolate multi-user.target
systemctl set-default multi-user.target
https://unix.stackexchange.com/questions/404667/systemd-service-what-is-multi-user-target
