# suckless terminal

Colored emojis doesn't work. Tried to install proper [library](https://www.reddit.com/r/i3wm/comments/frchjl/libxftbgra_for_ubuntu/), but with no luck.

