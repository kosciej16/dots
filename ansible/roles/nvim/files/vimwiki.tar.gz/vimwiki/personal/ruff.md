Config file - .ruff.toml (or ruff.toml or pyproject.toml)
Discovery - local and parents
