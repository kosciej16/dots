T - tagging messages
T. - all

;w/;W flags (N Not read, O old, D draft)
