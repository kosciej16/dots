[vim](vim)

[tmux](tmux)
[gnupg](gnupg)

/var/lib/dpkg/alternatives

[terminal](terminal)
[ssh](ssh)

[systemd](systemd)

[gnome](gnome)

[imap](imap)

[misc](misc)

[hardware](hardware)

[ssl](ssl)

[docker](docker)

[neomutt](neomutt)
validate sudo:
`Defaults:yourlogin !tty_tickets`
`sudo --validate`
