ga - get char code
:&& = g& - repeat last search

:.,+2s/\(\d\)/\=str2nr(submatch(1))+1

coc:
.vim for local settings
CocList extenions

vifm
- runexec

## Tags
checkpath
[I - print lines with keyword
