Inny output budowania dockera?

Zmienić w daemon.json
"buildkit": true  -> false

[registry](registry)


.docker/config.json do ustawiania parametrów (np. proxy)
