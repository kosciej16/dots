https://askubuntu.com/questions/182700/desktop-shortcut-for-terminal-command

/usr/share/applications

xdg-settings set default-web-browser name-of-browser.desktop
.config/mimeapps.list

