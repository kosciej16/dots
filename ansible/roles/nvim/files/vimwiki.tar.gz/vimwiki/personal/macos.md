Shortcuts

System preferences -> keyboard > shortcuts > App shortcuts add copy + paste
System preferences -> keyboard > modifier keys > swap modifiers keys

# keyboard tempo
defaults write -g InitialKeyRepeat -int 10 # normal minimum is 15 (225 ms)
defaults write -g KeyRepeat -int 1 # normal minimum is 2 (30 ms)

# Short password
pwpolicy -clearaccountpolicies


[yabai](yabai)
