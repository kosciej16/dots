[Firma](Firma)
[hiszpania](hiszpania)
[Bank](Bank)

Opuszczony posterunek policji - Konstancin Jeziorna
Opuszczony szpital psychiatryczny ,,Zofiówka" - Otwock
Opuszczona wieś - Bromierzyk
Opuszczony ośrodek nadawczy ,,Leszczynka" - Lesznowola
Atomowa kwatera dowodzenia - Łomianki
Opuszczony pałac ,,Satanistów" - Pruszków

Congratulations!
Welcome Krystian Dowolski! You have successfully completed your account activation.
Please record the following information for login purposes:

Your account number is: DS-E0DA66-4E
Your username is: kosciej16
