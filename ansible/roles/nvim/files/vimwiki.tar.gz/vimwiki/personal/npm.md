See the contents that will be included in the published version of the package.
`npx npm-packlist`

https://socket.dev/blog/inside-node-modules

If the filename passed to require is actually a directory, it will first look for package.json in the directory and load the file referenced in the main property. Otherwise, it will look for an index.js.
