Otherwise poetry takes OS version instead of pyenv
`poetry config virtualenvs.prefer-active-python true`

To create .venv in working directory, instead of ~/.cache/pypoetry
`poetry config virtualenvs.in-project true`


`poetry env use 3.10`
