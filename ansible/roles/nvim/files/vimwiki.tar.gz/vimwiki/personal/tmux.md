install tmux from repository
to change version:

# configure.ac
AC_INIT([tmux], 3.3)


:list-keys to get all command
