nc -z localhost
