Posortuj po timestamp od najnowszego, weź kolumny timestamp i InteractionId
.aggregate([{$sort: {timestamp: -1}}, {$project: {timestamp: 1, InteractionId: 1}}])

