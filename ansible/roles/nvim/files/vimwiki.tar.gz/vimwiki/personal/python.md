[poetry](poetry)
[alembic](alembic)
[setuptools](setuptools)
[gc](gc)
[ruff](ruff)

[pyenv](pyenv)

https://stackoverflow.com/a/65874499/3361462
s_new: bytes = bytes(s, encoding="raw_unicode_escape")

pip install memory_profiler
%load_ext memory_profiler
