eval "$(pyenv init --path)"
vs
eval "$(pyenv init -)"

Installs pyenv into the current shell as a shell function. This bit is also optional, but allows pyenv and plugins to change variables in your current shell. This is required for some commands like pyenv shell to work. The sh dispatcher doesn't do anything crazy like override cd or hack your shell prompt, but if for some reason you need pyenv to be a real script rather than a shell function, you can safely skip it.
