Disable System Integrity Protection
- Restart your computer in Recovery mode.
- Launch Terminal from the Utilities menu.
- Run the command csrutil disable.
- Restart your computer.

sudo yabai --install-sa
<on macos big sum>
sudo yabai --load-sa
