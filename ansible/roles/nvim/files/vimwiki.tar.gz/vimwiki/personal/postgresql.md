See last analyze:
select schemaname, relname, last_autoanalyze, last_analyze from pg_stat_all_tables where relname = 'table_name';

