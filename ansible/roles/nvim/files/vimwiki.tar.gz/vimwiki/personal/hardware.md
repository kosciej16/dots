Make touchpad works:

Install libinput

xinput list
xinput list-props
xinput set-prop
