[postgresql](postgresql)
Partition pruning (scan which partitions should be used)
JIT
Recursive queries (plannes things there is 10 levels)
