for (e of $('html').querySelectorAll("[class=zWGUib]").values()) console.log(e.textContent);

out=""; items=document.getElementsByClassName('zWGUib'); for (i=0; i<items.length; i++) { out += items[i].innerHTML + "\n";}; console.log(out);
