szpicel (snoop), denuncjator - osoba donosząca, kapuś
